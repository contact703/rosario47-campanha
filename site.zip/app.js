// Modal functions
function openSocialModal() {
  document.getElementById('socialModal').classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeSocialModal() {
  document.getElementById('socialModal').classList.remove('active');
  document.body.style.overflow = '';
}

function showLogin() {
  document.getElementById('loginForm').style.display = 'block';
  document.getElementById('registerForm').style.display = 'none';
  document.getElementById('socialContent').style.display = 'none';
}

function showRegister() {
  document.getElementById('loginForm').style.display = 'none';
  document.getElementById('registerForm').style.display = 'block';
  document.getElementById('socialContent').style.display = 'none';
}

function handleLogin() {
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  
  if (!email || !password) {
    alert('Preencha todos os campos!');
    return;
  }
  
  // Simulação de login
  localStorage.setItem('user', JSON.stringify({ email, name: email.split('@')[0] }));
  
  document.getElementById('loginForm').style.display = 'none';
  document.getElementById('socialContent').style.display = 'block';
}

function handleRegister() {
  const name = document.getElementById('registerName').value;
  const email = document.getElementById('registerEmail').value;
  const password = document.getElementById('registerPassword').value;
  
  if (!name || !email || !password) {
    alert('Preencha todos os campos!');
    return;
  }
  
  // Simulação de registro
  localStorage.setItem('user', JSON.stringify({ email, name }));
  
  document.getElementById('registerForm').style.display = 'none';
  document.getElementById('socialContent').style.display = 'block';
}

function showTab(tabName) {
  // Remove active class from all tabs and contents
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(content => content.style.display = 'none');
  
  // Add active class to selected tab
  event.target.classList.add('active');
  document.getElementById(tabName + 'Tab').style.display = 'block';
}

// Navigation
function toggleMenu() {
  const nav = document.querySelector('.nav');
  nav.classList.toggle('active');
}

// Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
    }
  });
});

// Active nav link on scroll
window.addEventListener('scroll', () => {
  const sections = document.querySelectorAll('section');
  const navLinks = document.querySelectorAll('.nav-link');
  
  let current = '';
  
  sections.forEach(section => {
    const sectionTop = section.offsetTop;
    if (pageYOffset >= sectionTop - 100) {
      current = section.getAttribute('id');
    }
  });
  
  navLinks.forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('href') === '#' + current) {
      link.classList.add('active');
    }
  });
});

// Check if user is already logged in
document.addEventListener('DOMContentLoaded', () => {
  const user = localStorage.getItem('user');
  if (user) {
    // User is logged in, show social content on modal open
  }
});

// Close modal on background click
document.getElementById('socialModal').addEventListener('click', (e) => {
  if (e.target.id === 'socialModal') {
    closeSocialModal();
  }
});

// Close modal on Escape key
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeSocialModal();
  }
});
