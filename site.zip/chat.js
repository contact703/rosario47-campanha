// Base de conhecimento do candidato
const CONHECIMENTO = {
  candidato: {
    nome: 'Antunes do Rosário',
    numero: '47',
    cargo: 'Vereador',
    partido: 'Partido da causa popular',
    slogan: 'Por um futuro melhor para todos!',
    historia: 'Antunes do Rosário nasceu e cresceu na comunidade. Trabalhou como professor por 15 anos e sempre lutou pelos direitos do povo. Agora quer levar essa luta para a Câmara Municipal.',
  },
  propostas: {
    saude: [
      'Ampliar horário dos postos de saúde até 22h',
      'Trazer mais médicos especialistas',
      'UPA 24h funcionando com equipe completa',
      'Mutirões mensais de exames preventivos',
      'Fortalecer o CAPS para saúde mental',
    ],
    educacao: [
      'Ar condicionado em todas as salas de aula',
      'Quadras esportivas cobertas',
      'Valorização dos professores',
      'Mais vagas em creches públicas',
      'Cursos profissionalizantes gratuitos',
    ],
    transporte: [
      'Mais linhas de ônibus nos bairros',
      'Tarifa social para desempregados',
      'Ciclovias conectando os bairros',
      'Transporte escolar gratuito',
    ],
    seguranca: [
      'Iluminação pública em todas as ruas',
      'Ronda municipal nos bairros',
      'Câmeras de segurança nas praças',
      'Guarda municipal 24h',
    ],
  },
  eventos: [
    { nome: 'Carreata', data: 'Sábado 14h', local: 'Praça Central' },
    { nome: 'Reunião com moradores', data: 'Terça 19h', local: 'Comitê' },
    { nome: 'Panfletagem', data: 'Quarta 8h', local: 'Feira do Centro' },
    { nome: 'Debate', data: 'Quinta 20h', local: 'Câmara Municipal' },
  ],
  contato: {
    whatsapp: '(31) 99999-9999',
    email: 'contato@rosario47.com.br',
    endereco: 'Rua Principal, 123 - Centro',
    instagram: '@rosario47',
  },
};

// Palavras-chave
const KEYWORDS = {
  saude: ['saúde', 'saude', 'médico', 'medico', 'hospital', 'posto', 'upa', 'doença', 'remédio', 'farmácia', 'caps'],
  educacao: ['educação', 'educacao', 'escola', 'professor', 'aluno', 'creche', 'estudar', 'ensino'],
  transporte: ['transporte', 'ônibus', 'onibus', 'tarifa', 'passagem', 'ciclovia'],
  seguranca: ['segurança', 'seguranca', 'policia', 'polícia', 'roubo', 'iluminação', 'câmera', 'guarda'],
  candidato: ['antunes', 'rosário', 'rosario', 'candidato', 'quem é', 'quem e', 'história', 'biografia'],
  numero: ['número', 'numero', 'votar', 'voto', '47', 'eleição', 'urna'],
  propostas: ['proposta', 'plano', 'projeto', 'vai fazer', 'pretende', 'ideia'],
  eventos: ['evento', 'carreata', 'reunião', 'panfletagem', 'debate', 'quando', 'onde'],
  contato: ['contato', 'telefone', 'whatsapp', 'zap', 'email', 'endereço', 'instagram'],
  saudacao: ['oi', 'olá', 'ola', 'bom dia', 'boa tarde', 'boa noite', 'eae', 'opa'],
  ajuda: ['ajuda', 'ajudar', 'help', 'como funciona', 'comandos'],
  agradecimento: ['obrigado', 'obrigada', 'valeu', 'brigado'],
};

function detectarIntencao(texto) {
  const textoLower = texto.toLowerCase();
  const intencoes = [];
  
  for (const [intencao, palavras] of Object.entries(KEYWORDS)) {
    for (const palavra of palavras) {
      if (textoLower.includes(palavra)) {
        if (!intencoes.includes(intencao)) {
          intencoes.push(intencao);
        }
        break;
      }
    }
  }
  
  return intencoes.length > 0 ? intencoes : ['geral'];
}

function gerarResposta(intencoes) {
  const respostas = [];
  
  for (const intencao of intencoes) {
    switch (intencao) {
      case 'saudacao':
        respostas.push(`Olá! 👋 Sou o assistente virtual do ${CONHECIMENTO.candidato.nome} ${CONHECIMENTO.candidato.numero}!\n\nEstou aqui para te contar tudo sobre nosso candidato. O que você quer saber?`);
        break;
        
      case 'candidato':
        respostas.push(`📋 Sobre ${CONHECIMENTO.candidato.nome}\n\n${CONHECIMENTO.candidato.historia}\n\n🎯 Número na urna: ${CONHECIMENTO.candidato.numero}\n🏛️ Candidato a: ${CONHECIMENTO.candidato.cargo}\n\n"${CONHECIMENTO.candidato.slogan}"`);
        break;
        
      case 'numero':
        respostas.push(`🗳️ O número do ${CONHECIMENTO.candidato.nome} é ${CONHECIMENTO.candidato.numero}!\n\nNa hora de votar, digite ${CONHECIMENTO.candidato.numero} e confirme!\n\n💚 Juntos por um futuro melhor!`);
        break;
        
      case 'saude':
        const propostasSaude = CONHECIMENTO.propostas.saude.map(p => `• ${p}`).join('\n');
        respostas.push(`🏥 Propostas para Saúde\n\n${propostasSaude}\n\n${CONHECIMENTO.candidato.nome} sabe que saúde é prioridade!`);
        break;
        
      case 'educacao':
        const propostasEducacao = CONHECIMENTO.propostas.educacao.map(p => `• ${p}`).join('\n');
        respostas.push(`📚 Propostas para Educação\n\n${propostasEducacao}\n\nComo ex-professor, ${CONHECIMENTO.candidato.nome} conhece os desafios da educação!`);
        break;
        
      case 'transporte':
        const propostasTransporte = CONHECIMENTO.propostas.transporte.map(p => `• ${p}`).join('\n');
        respostas.push(`🚌 Propostas para Transporte\n\n${propostasTransporte}\n\nMobilidade é direito de todos!`);
        break;
        
      case 'seguranca':
        const propostasSeguranca = CONHECIMENTO.propostas.seguranca.map(p => `• ${p}`).join('\n');
        respostas.push(`🛡️ Propostas para Segurança\n\n${propostasSeguranca}\n\nSegurança começa com prevenção!`);
        break;
        
      case 'propostas':
        respostas.push(`📋 Áreas de atuação do ${CONHECIMENTO.candidato.nome}:\n\n🏥 Saúde - Mais médicos e postos funcionando\n📚 Educação - Escolas com estrutura\n🚌 Transporte - Mais linhas, tarifa justa\n🛡️ Segurança - Iluminação e ronda\n\nQuer saber detalhes de alguma área?`);
        break;
        
      case 'eventos':
        const eventosLista = CONHECIMENTO.eventos.map(e => `📅 ${e.nome}\n   ${e.data} - ${e.local}`).join('\n\n');
        respostas.push(`🗓️ Próximos Eventos\n\n${eventosLista}\n\nVenha participar!`);
        break;
        
      case 'contato':
        respostas.push(`📞 Contato da Campanha\n\n📱 WhatsApp: ${CONHECIMENTO.contato.whatsapp}\n📧 Email: ${CONHECIMENTO.contato.email}\n📍 Comitê: ${CONHECIMENTO.contato.endereco}\n📸 Instagram: ${CONHECIMENTO.contato.instagram}`);
        break;
        
      case 'ajuda':
        respostas.push(`🤖 Como posso ajudar?\n\nPosso te contar sobre:\n\n• Quem é ${CONHECIMENTO.candidato.nome}\n• Propostas (saúde, educação, transporte...)\n• Eventos da campanha\n• Contato da equipe\n• Número para votar\n\nÉ só perguntar!`);
        break;
        
      case 'agradecimento':
        respostas.push(`😊 Por nada! Estou aqui para ajudar!\n\nLembre-se: ${CONHECIMENTO.candidato.nome} é ${CONHECIMENTO.candidato.numero}!`);
        break;
        
      case 'geral':
      default:
        respostas.push(`Posso te ajudar com:\n\n• Propostas do ${CONHECIMENTO.candidato.nome}\n• Eventos da campanha\n• Informações de contato\n• Número para votar\n\nDigite "ajuda" para ver o que sei!`);
        break;
    }
  }
  
  return respostas.length > 1 ? respostas.slice(0, 2).join('\n\n---\n\n') : respostas[0];
}

// Chat functions
let isSpeaking = false;
let isRecording = false;

function addMessage(text, isUser = false) {
  const messagesContainer = document.getElementById('chatMessages');
  
  const messageDiv = document.createElement('div');
  messageDiv.className = `message ${isUser ? 'user' : ''}`;
  
  const avatar = document.createElement('div');
  avatar.className = 'message-avatar';
  avatar.textContent = isUser ? 'V' : '47';
  
  const content = document.createElement('div');
  content.className = 'message-content';
  
  const p = document.createElement('p');
  p.textContent = text;
  content.appendChild(p);
  
  if (!isUser) {
    const speakBtn = document.createElement('button');
    speakBtn.className = 'message-speak';
    speakBtn.innerHTML = '<i class="fas fa-volume-up"></i> Ouvir';
    speakBtn.onclick = () => speakText(text);
    content.appendChild(speakBtn);
  }
  
  messageDiv.appendChild(avatar);
  messageDiv.appendChild(content);
  
  messagesContainer.appendChild(messageDiv);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function addTypingIndicator() {
  const messagesContainer = document.getElementById('chatMessages');
  
  const typingDiv = document.createElement('div');
  typingDiv.className = 'message';
  typingDiv.id = 'typing-indicator';
  
  const avatar = document.createElement('div');
  avatar.className = 'message-avatar';
  avatar.textContent = '47';
  
  const typing = document.createElement('div');
  typing.className = 'typing-indicator';
  typing.innerHTML = '<span></span><span></span><span></span>';
  
  typingDiv.appendChild(avatar);
  typingDiv.appendChild(typing);
  
  messagesContainer.appendChild(typingDiv);
  messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function removeTypingIndicator() {
  const typing = document.getElementById('typing-indicator');
  if (typing) typing.remove();
}

function sendMessage() {
  const input = document.getElementById('chatInput');
  const text = input.value.trim();
  
  if (!text) return;
  
  addMessage(text, true);
  input.value = '';
  
  addTypingIndicator();
  
  setTimeout(() => {
    removeTypingIndicator();
    const intencoes = detectarIntencao(text);
    const resposta = gerarResposta(intencoes);
    addMessage(resposta);
  }, 800 + Math.random() * 800);
}

function quickMessage(text) {
  document.getElementById('chatInput').value = text;
  sendMessage();
}

function handleKeyPress(event) {
  if (event.key === 'Enter') {
    sendMessage();
  }
}

function speakText(text) {
  if (isSpeaking) {
    speechSynthesis.cancel();
    isSpeaking = false;
    return;
  }
  
  const cleanText = text.replace(/[📋🏥📚🚌🛡️🎯🏛️📅📞📱📧📍📸🤖😊💚🗳️👋]/g, '').replace(/•/g, '').trim();
  
  const utterance = new SpeechSynthesisUtterance(cleanText);
  utterance.lang = 'pt-BR';
  utterance.rate = 0.9;
  
  utterance.onend = () => {
    isSpeaking = false;
  };
  
  isSpeaking = true;
  speechSynthesis.speak(utterance);
}

function toggleVoice() {
  const btn = document.getElementById('voiceBtn');
  
  if (isRecording) {
    btn.classList.remove('recording');
    isRecording = false;
    // Por enquanto, só mostra alerta
    alert('Reconhecimento de voz requer integração com serviço externo (Google Speech, etc). Por enquanto, digite sua mensagem.');
  } else {
    btn.classList.add('recording');
    isRecording = true;
    
    // Check if browser supports speech recognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = 'pt-BR';
      recognition.continuous = false;
      
      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        document.getElementById('chatInput').value = transcript;
        btn.classList.remove('recording');
        isRecording = false;
      };
      
      recognition.onerror = () => {
        btn.classList.remove('recording');
        isRecording = false;
      };
      
      recognition.onend = () => {
        btn.classList.remove('recording');
        isRecording = false;
      };
      
      recognition.start();
    } else {
      btn.classList.remove('recording');
      isRecording = false;
      alert('Seu navegador não suporta reconhecimento de voz. Use Chrome para esta funcionalidade.');
    }
  }
}

// Initialize chat with welcome message
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    addMessage(`Olá! 👋 Sou o assistente virtual do ${CONHECIMENTO.candidato.nome} ${CONHECIMENTO.candidato.numero}!\n\nPosso te ajudar com:\n• Propostas do candidato\n• Eventos da campanha\n• Informações de contato\n\nComo posso ajudar?`);
  }, 500);
});
